// Replace image links with local image paths
const startup_images = [
    'image1.png',
    'image2.png',
    'image3.png',
    'image1.png'
];

const background_image = 'status.png'; // Adjust this if your background image is local as well

const existing_user_image = 'airdrop.png'; // Replace with actual path to existing user image

// Function to check if user is on mobile
function isMobile() {
    return /Android|iPhone|iPad|iPod|IEMobile|Opera Mini/i.test(navigator.userAgent);
}

// Function to check if Telegram ID exists in users.json
async function checkUser(telegramId) {
    console.log("Checking user for Telegram ID:", telegramId);
    try {
        const response = await fetch('/users'); // Fetch from GET /users
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        const users = await response.json();
        console.log("Fetched users.json:", users);

        if (!telegramId || !users[telegramId]) {
            // Telegram ID not found, show startup images
            showImagesWithDelay(startup_images, () => {
                // Hide image container and display background after images
                document.getElementById('image-container').style.display = 'none';
                document.body.style.backgroundImage = `url(${background_image})`;
                document.body.style.backgroundSize = 'cover';  // Ensure background image covers the screen
                document.getElementById('username-section').style.display = 'block';
            });
        } else {
            // Telegram ID found, show existing user image and loading circle
            showExistingUserImageWithLoadingCircle(users[telegramId].username);
        }
    } catch (error) {
        console.error('Error fetching users.json:', error);
        document.getElementById('message').innerText = 'An error occurred. Please try again later.';
    }
}

// Function to show existing user image with a loading circle
function showExistingUserImageWithLoadingCircle(username) {
    const imgContainer = document.getElementById('image-container');
    imgContainer.innerHTML = `<img src="${existing_user_image}" alt="Existing User" id="existing-user-image" />
                              <div class="loading-circle"></div>`;
    imgContainer.style.display = 'flex';
    imgContainer.style.justifyContent = 'center';
    imgContainer.style.alignItems = 'center';

    // Set a timer for 7 seconds before redirecting
    setTimeout(() => {
        window.location.href = 'index2.html?username=' + encodeURIComponent(username);
    }, 7000); // 7 seconds
}

// Function to display images with a delay
function showImagesWithDelay(images, callback = null) {
    let index = 0;
    const imgContainer = document.getElementById('image-container');
    const interval = setInterval(() => {
        if (index < images.length) {
            imgContainer.innerHTML = `<img src="${images[index]}" alt="Image ${index + 1}" />`;
            index++;
        } else {
            clearInterval(interval);
            if (callback) callback();
        }
    }, 2000); // 2-second delay
}

// Function to submit username
async function submitUsername() {
    const username = document.getElementById('username-input').value.trim();
    const telegramId = new URLSearchParams(window.location.search).get('telegramid');

    if (!username) {
        displayMessage('Username cannot be empty.', 'error');
        return;
    }

    console.log("Submitting username:", username, "for Telegram ID:", telegramId);

    try {
        const response = await fetch('/users');
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        const users = await response.json();
        console.log("Fetched users.json for validation:", users);

        // Check if username already exists
        const usernameExists = Object.values(users).some(user => user.username.toLowerCase() === username.toLowerCase());
        if (usernameExists) {
            displayMessage('This username is already in use. Please try another one.', 'error');
            return;
        }

        // Save new user to users.json
        users[telegramId] = { telegramid: telegramId, username: username };
        console.log("Updated users object:", users);

        const updateResponse = await fetch('/users', {
            method: 'POST',
            body: JSON.stringify(users),
            headers: {
                'Content-Type': 'application/json'
            }
        });

        if (!updateResponse.ok) {
            throw new Error('Failed to update users.json');
        }

        displayMessage('Username saved successfully!', 'success');
        // Redirect to index2.html with username as a URL parameter
        window.location.href = `index2.html?username=${encodeURIComponent(username)}`;
    } catch (error) {
        console.error('Error updating users.json:', error);
        displayMessage('An error occurred while saving your username. Please try again.', 'error');
    }
}

// Function to display messages to the user
function displayMessage(msg, type) {
    const messageElem = document.getElementById('message');
    messageElem.innerText = msg;
    if (type === 'error') {
        messageElem.style.color = 'red';
    } else if (type === 'success') {
        messageElem.style.color = 'green';
    } else {
        messageElem.style.color = 'black';
    }
}

// Initialize the page
document.addEventListener('DOMContentLoaded', () => {
    const telegramId = new URLSearchParams(window.location.search).get('telegramid');
    if (!isMobile()) {
        displayMessage('You can only play this game on mobile!', 'error');
    } else {
        checkUser(telegramId);
    }
});

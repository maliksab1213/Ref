let username; // Declare username in the global scope
let activeTimers = {};
document.addEventListener('DOMContentLoaded', async () => {
    const urlParams = new URLSearchParams(window.location.search);
    username = urlParams.get('username'); // Assign to the global variable

    if (!username) {
        displayError('Username not provided.');
        return;
    }

    document.getElementById('usernameDisplay').innerText = username;
    await fetchAndDisplayCoins();

    await showSection('home');

    document.querySelectorAll('.nav-button').forEach(button => {
        button.addEventListener('click', async (e) => {
            e.preventDefault();
            const section = button.getAttribute('data-section');
            await showSection(section);
        });
    });

    document.getElementById('backButton').addEventListener('click', async () => {
        await showSection('home');
    });

    setInterval(fetchAndDisplayCoins, 5000);
});

async function fetchAndDisplayCoins() {
    try {
        const coinsResponse = await fetch(`/coins?username=${encodeURIComponent(username)}`);
        if (!coinsResponse.ok) {
            throw new Error('Failed to fetch coins data.');
        }
        const coinsData = await coinsResponse.json();
        let coins = Number(coinsData.coins);
        if (isNaN(coins)) {
            coins = 0;
        }
        document.getElementById('coinsDisplay').innerText = `${coins} Coins`;
    } catch (error) {
        console.error('Error fetching coins:', error);
        displayError('Failed to load coins data.');
    }
}

async function getSectionContent(section) {
    const response = await fetch(`${section}.html`);
    if (!response.ok) {
        displayError('Failed to load section content.');
        return '<h2>Error</h2><p>Failed to load content.</p>';
    }
    return await response.text();
}

async function showSection(section) {
    const sections = ['home', 'tasks', 'freeCredit', 'miniGames', 'status', 'airdrop'];
    const content = document.getElementById('mainContent');
    const header = document.getElementById('headerSection');

    if (!sections.includes(section)) {
        displayError('Invalid section.');
        return;
    }

    header.style.display = 'none';

    content.innerHTML = await getSectionContent(section);

    if (section === 'tasks') {
        await loadTasks();
    }

    content.style.display = 'block';

    if (section !== 'home') {
        document.getElementById('backButton').style.display = 'block';
    } else {
        header.style.display = 'flex';
        document.getElementById('backButton').style.display = 'none';
    }
}

async function loadTasks() {
    try {
        if (!username) {
            throw new Error('Username not provided.');
        }

        const response = await fetch(`/tasks?username=${encodeURIComponent(username)}`);

        if (!response.ok) {
            throw new Error('Failed to load tasks from the server.');
        }

        const tasks = await response.json();

        console.log('Loaded tasks:', tasks);

        if (!tasks.dailyTasks || !tasks.socialMediaTasks) {
            throw new Error('Invalid task data received. Missing dailyTasks or socialMediaTasks.');
        }

        renderTasks(tasks.dailyTasks, 'dailyTaskList');
        renderTasks(tasks.socialMediaTasks, 'socialMediaTaskList');
    } catch (error) {
        console.error('Error loading tasks:', error);
        displayError('Error loading tasks: ' + error.message);
    }
}

function renderTasks(tasks, containerId) {
    const container = document.getElementById(containerId);
    if (!container) return;

    container.innerHTML = '';

    tasks.forEach(task => {
        const taskElement = document.createElement('div');
        taskElement.className = 'task-item';
        taskElement.id = task.taskId;

        taskElement.innerHTML = `
            <div class="task-info">
                <div class="task-details">${task.name}</div>
            </div>
            <div class="task-action">
                <button class="points-button">${task.completed ? "Completed" : "+" + task.points}</button>
                <button class="check-button" style="display: none;">Check</button>
            </div>
        `;

        const pointsButton = taskElement.querySelector('.points-button');
        const checkButton = taskElement.querySelector('.check-button');

        if (task.completed) {
            pointsButton.disabled = true;
            pointsButton.style.backgroundColor = '#a5a5a5';
        } else {
            pointsButton.onclick = () => openTask(task.url, pointsButton, checkButton, task.timer);
            checkButton.onclick = () => completeTask(checkButton, task.points, taskElement);
        }

        container.appendChild(taskElement);
    });
}

function openTask(url, pointsButton, checkButton, timerDuration) {
    window.open(url, '_blank');
    pointsButton.style.display = "none";
    checkButton.style.display = "block";
    checkButton.disabled = true;

    const taskId = checkButton.closest('.task-item').id;
    let timeLeft = timerDuration;

    const timerId = setInterval(() => {
        timeLeft--;

        if (timeLeft <= 0) {
            clearInterval(timerId);
            checkButton.disabled = false;
        }
    }, 1000);

    activeTimers[taskId] = { timerId, endTime: Date.now() + timerDuration * 1000 };
}

async function completeTask(checkButton, points, taskElement) {
    const taskId = taskElement.id;

    if (!username) {
        console.error('Username is not available');
        return;
    }

    if (!taskId) {
        console.error('Task ID is not available');
        return;
    }

    const timer = activeTimers[taskId];
    if (timer) {
        clearInterval(timer.timerId);
        const timeLeft = Math.max(0, timer.endTime - Date.now());

        if (timeLeft > 0) {
            const secondsLeft = Math.ceil(timeLeft / 1000);
            alert(`Please wait ${secondsLeft} more seconds before completing the task.`);
            return;
        }

        delete activeTimers[taskId];
    }

    checkButton.innerText = "Completed";
    checkButton.disabled = true;
    taskElement.style.opacity = "0.5";

    try {
        const response = await fetch("/tasks/complete", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify({ username, taskId, points }),
        });

        const data = await response.json();
        if (response.ok) {
            console.log(`Task completed: ${data.message}`);
            await fetchAndDisplayCoins();
        } else {
            console.error(`Error completing task: ${data.error}`);
            checkButton.innerText = "Check";
            checkButton.disabled = false;
            taskElement.style.opacity = "1";
        }
    } catch (error) {
        console.error('Network error:', error);
        checkButton.innerText = "Check";
        checkButton.disabled = false;
        taskElement.style.opacity = "1";
    }
}

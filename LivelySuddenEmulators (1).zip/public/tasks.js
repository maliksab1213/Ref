async function loadTasks() {
    try {
        const response = await fetch('tasks.json');
        const tasks = await response.json();
        renderTasks(tasks.dailyTasks, 'dailyTaskList');
        renderTasks(tasks.socialMediaTasks, 'socialMediaTaskList');
    } catch (error) {
        console.error('Error loading tasks:', error);
    }
}

function renderTasks(tasks, containerId) {
    const container = document.getElementById(containerId);
    
    tasks.forEach(task => {
        const taskElement = document.createElement('div');
        taskElement.className = 'task-item';
        taskElement.innerHTML = `
            <div class="task-info">
                <div class="task-details">${task.name}</div>
            </div>
            <div class="task-action">
                <button class="points-button">+${task.points}</button>
                <button class="check-button" style="display: none;">Check</button>
            </div>
        `;

        const pointsButton = taskElement.querySelector('.points-button');
        const checkButton = taskElement.querySelector('.check-button');

        pointsButton.onclick = () => openTask(task.url, pointsButton, checkButton);
        checkButton.onclick = () => completeTask(checkButton, task.points, taskElement);

        container.appendChild(taskElement);
    });
}

function openTask(url, pointsButton, checkButton) {
    window.open(url, '_blank');
    pointsButton.style.display = "none";
    checkButton.style.display = "block";
}

async function completeTask(checkButton, points, taskElement) {
    checkButton.innerText = "Completed";
    checkButton.disabled = true;
    taskElement.style.opacity = "0.5";

    try {
        const response = await fetch("/tasks/complete", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify({ points }),
        });

        const data = await response.json();
        if (response.ok) {
            console.log(`Task completed, coins updated: ${data.coins}`);
            // You might want to update the user's coin display here
        } else {
            console.error(`Error completing task: ${data.error}`);
        }
    } catch (error) {
        console.error('Network error:', error);
    }
}

document.addEventListener('DOMContentLoaded', loadTasks);
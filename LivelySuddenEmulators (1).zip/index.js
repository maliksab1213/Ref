const express = require("express");
const path = require("path");
const fs = require("fs");
const bodyParser = require("body-parser");
const axios = require("axios"); // Ensure you have axios installed for making HTTP requests

const app = express();


// Middleware to parse JSON bodies
app.use(bodyParser.json());

// Serve static files from the 'public' directory
app.use(express.static(path.join(__dirname, 'public')));

// Ensure 'userdata' directory exists
const userdataDir = path.join(__dirname, 'userdata');
if (!fs.existsSync(userdataDir)) {
    fs.mkdirSync(userdataDir, { recursive: true });
    console.log("'userdata' directory created.");
}

// Route to get coins for a user
app.get("/coins", (req, res) => {
    const username = req.query.username;
    if (!username) {
        return res.status(400).json({ error: "Username is required" });
    }

    const userDir = path.join(userdataDir, username);
    const coinsFilePath = path.join(userDir, 'coins.txt');

    // Check if user directory exists; if not, create it
    if (!fs.existsSync(userDir)) {
        fs.mkdirSync(userDir, { recursive: true });
        console.log(`User directory created for ${username}.`);
    }

    // Check if coins.txt exists; if not, create it with 0
    if (!fs.existsSync(coinsFilePath)) {
        fs.writeFileSync(coinsFilePath, '0', 'utf8');
        console.log(`coins.txt created for ${username} with initial value 0.`);
    }

    // Read the coins value
    fs.readFile(coinsFilePath, 'utf8', (err, data) => {
        if (err) {
            console.error(`Error reading coins for user ${username}:`, err);
            return res.status(500).json({ error: "Internal Server Error" });
        }
        const coins = Number(data.trim()) || 0;
        res.json({ coins });
    });
});
app.get("/users", (req, res) => {
  fs.readFile(path.join(__dirname, 'public', 'users.json'), 'utf8', (err, data) => {
      if (err) {
          console.error("Error reading users.json:", err);
          return res.status(500).json({ error: "Internal Server Error" });
      }
      res.setHeader('Content-Type', 'application/json');
      res.send(data);
  });
});

// Route to update users.json
app.post("/users", (req, res) => {
  const updatedUsers = req.body;

  // Server-side validation
  if (typeof updatedUsers !== 'object' || Array.isArray(updatedUsers)) {
      return res.status(400).json({ error: "Invalid data format" });
  }

  // Read existing users to identify new users
  fs.readFile(path.join(__dirname, 'public', 'users.json'), 'utf8', (err, data) => {
      if (err && err.code !== 'ENOENT') { // Allow ENOENT if users.json doesn't exist yet
          console.error("Error reading users.json:", err);
          return res.status(500).json({ error: "Internal Server Error" });
      }

      let existingUsers = {};
      if (data) {
          try {
              existingUsers = JSON.parse(data);
          } catch (parseErr) {
              console.error("Error parsing users.json:", parseErr);
              return res.status(500).json({ error: "Internal Server Error" });
          }
      }

      // Identify new users
      const newUsers = Object.keys(updatedUsers).filter(user => !existingUsers[user]);

      // Initialize userdata for new users
      newUsers.forEach(username => {
          const userDir = path.join(userdataDir, username);
          const coinsFilePath = path.join(userDir, 'coins.txt');

          if (!fs.existsSync(userDir)) {
              fs.mkdirSync(userDir, { recursive: true });
              console.log(`User directory created for ${username}.`);
          }

          if (!fs.existsSync(coinsFilePath)) {
              fs.writeFileSync(coinsFilePath, '0', 'utf8');
              console.log(`coins.txt created for new user ${username} with initial value 0.`);
          }
      });

      // Now, write the updated users.json
      fs.writeFile(path.join(__dirname, 'public', 'users.json'), JSON.stringify(updatedUsers, null, 2), 'utf8', (writeErr) => {
          if (writeErr) {
              console.error("Error writing to users.json:", writeErr);
              return res.status(500).json({ error: "Internal Server Error" });
          }
          res.json({ status: "success" });
      });
  });
});
// Route to increase coins for a user
app.post("/coins/increase", (req, res) => {
    const { username, amount } = req.body;

    if (!username || typeof amount !== 'number' || amount <= 0) {
        return res.status(400).json({ error: "Valid username and amount are required" });
    }

    const userDir = path.join(userdataDir, username);
    const coinsFilePath = path.join(userDir, 'coins.txt');

    // Ensure user directory exists
    if (!fs.existsSync(userDir)) {
        fs.mkdirSync(userDir, { recursive: true });
        console.log(`User directory created for ${username}.`);
    }

    // Check if coins.txt exists; if not, create it with 0
    if (!fs.existsSync(coinsFilePath)) {
        fs.writeFileSync(coinsFilePath, '0', 'utf8');
        console.log(`coins.txt created for ${username} with initial value 0.`);
    }

    // Read current coins
    fs.readFile(coinsFilePath, 'utf8', (readErr, data) => {
        if (readErr) {
            console.error(`Error reading coins for user ${username}:`, readErr);
            return res.status(500).json({ error: "Internal Server Error" });
        }

        let currentCoins = Number(data.trim()) || 0;
        let newCoins = currentCoins + amount;

        // Write updated coins
        fs.writeFile(coinsFilePath, newCoins.toString(), 'utf8', (writeErr) => {
            if (writeErr) {
                console.error(`Error writing coins for user ${username}:`, writeErr);
                return res.status(500).json({ error: "Internal Server Error" });
            }
            res.json({ status: "success", coins: newCoins });
        });
    });
});

// Optional: Route to decrease coins for a user
app.post("/coins/decrease", (req, res) => {
    const { username, amount } = req.body;

    if (!username || typeof amount !== 'number' || amount <= 0) {
        return res.status(400).json({ error: "Valid username and amount are required" });
    }

    const userDir = path.join(userdataDir, username);
    const coinsFilePath = path.join(userDir, 'coins.txt');

    // Ensure user directory exists
    if (!fs.existsSync(userDir)) {
        fs.mkdirSync(userDir, { recursive: true });
        console.log(`User directory created for ${username}.`);
    }

    // Check if coins.txt exists; if not, create it with 0
    if (!fs.existsSync(coinsFilePath)) {
        fs.writeFileSync(coinsFilePath, '0', 'utf8');
        console.log(`coins.txt created for ${username} with initial value 0.`);
    }

    // Read current coins
    fs.readFile(coinsFilePath, 'utf8', (readErr, data) => {
        if (readErr) {
            console.error(`Error reading coins for user ${username}:`, readErr);
            return res.status(500).json({ error: "Internal Server Error" });
        }

        let currentCoins = Number(data.trim()) || 0;
        let newCoins = currentCoins - amount;

        if (newCoins < 0) newCoins = 0; // Prevent negative coins

        // Write updated coins
        fs.writeFile(coinsFilePath, newCoins.toString(), 'utf8', (writeErr) => {
            if (writeErr) {
                console.error(`Error writing coins for user ${username}:`, writeErr);
                return res.status(500).json({ error: "Internal Server Error" });
            }
            res.json({ status: "success", coins: newCoins });
        });
    });
});

app.use(express.static('public'));

// Define the /tasks endpoint to fetch task data from user-specific file
const defaultTasksPath = path.join(__dirname, 'tasks.json');

app.get('/tasks', (req, res) => {
    const { username } = req.query;

    if (!username) {
        return res.status(400).json({ error: 'Username is required.' });
    }

    const userTasksDir = path.join(__dirname, 'tasks', username);
    const userTasksFile = path.join(userTasksDir, 'tasks.json');

    fs.mkdir(userTasksDir, { recursive: true }, (err) => {
        if (err) {
            return res.status(500).json({ error: 'Failed to create user tasks directory.' });
        }

        fs.readFile(userTasksFile, 'utf8', (err, data) => {
            if (err) {
                if (err.code === 'ENOENT') {
                    console.log('tasks.json not found for user, copying default...');
                    fs.copyFile(defaultTasksPath, userTasksFile, (copyErr) => {
                        if (copyErr) {
                            return res.status(500).json({ error: 'Failed to copy default tasks.json.' });
                        }
                        readTasksFile(userTasksFile, res);
                    });
                } else {
                    return res.status(500).json({ error: 'Error reading tasks file.' });
                }
            } else {
                readTasksFile(userTasksFile, res, data);
            }
        });
    });
});

function readTasksFile(userTasksFile, res, data) {
    if (!data) {
        fs.readFile(userTasksFile, 'utf8', (err, newData) => {
            if (err) {
                return res.status(500).json({ error: 'Error reading tasks data.' });
            }
            return sendTasksData(newData, res);
        });
    } else {
        sendTasksData(data, res);
    }
}

function sendTasksData(data, res) {
    try {
        const tasks = JSON.parse(data);
        // Ensure each task has a timer property
        ['dailyTasks', 'socialMediaTasks'].forEach(taskType => {
            tasks[taskType].forEach(task => {
                if (!task.hasOwnProperty('timer')) {
                    task.timer = 180; // Default timer value if not set
                }
            });
        });
        res.json(tasks);
    } catch (error) {
        res.status(500).json({ error: 'Error parsing tasks data.' });
    }
}

// Serve static files (optional if you have other resources)
app.use(express.static(path.join(__dirname, 'public')));

app.post('/tasks/complete', (req, res) => {
    const { username, taskId, points } = req.body;

    if (!username || !taskId || typeof points !== 'number') {
        return res.status(400).json({ error: 'Username, taskId, and points are required.' });
    }

    const userTasksDir = path.join(__dirname, 'tasks', username);
    const userTasksFile = path.join(userTasksDir, 'tasks.json');
    const userCoinsFile = path.join(userdataDir, username, 'coins.txt');

    // Read and update tasks
    fs.readFile(userTasksFile, 'utf8', (err, taskData) => {
        if (err) {
            return res.status(500).json({ error: 'Error reading tasks file.' });
        }

        try {
            const tasks = JSON.parse(taskData);
            let taskUpdated = false;

            ['dailyTasks', 'socialMediaTasks'].forEach(taskType => {
                const taskIndex = tasks[taskType].findIndex(task => task.taskId === taskId);
                if (taskIndex !== -1) {
                    tasks[taskType][taskIndex].completed = true;
                    taskUpdated = true;
                }
            });

            if (!taskUpdated) {
                return res.status(404).json({ error: 'Task not found.' });
            }

            // Update tasks file
            fs.writeFile(userTasksFile, JSON.stringify(tasks, null, 2), 'utf8', (writeErr) => {
                if (writeErr) {
                    return res.status(500).json({ error: 'Error updating tasks file.' });
                }

                // Update coins
                fs.readFile(userCoinsFile, 'utf8', (readErr, coinData) => {
                    if (readErr) {
                        return res.status(500).json({ error: 'Error reading coins file.' });
                    }

                    let currentCoins = Number(coinData.trim()) || 0;
                    let newCoins = currentCoins + points;

                    fs.writeFile(userCoinsFile, newCoins.toString(), 'utf8', (coinWriteErr) => {
                        if (coinWriteErr) {
                            return res.status(500).json({ error: 'Error updating coins file.' });
                        }
                        res.json({ status: 'success', message: 'Task marked as completed and coins updated.', newCoins });
                    });
                });
            });
        } catch (parseError) {
            res.status(500).json({ error: 'Error parsing tasks data.' });
        }
    });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log("Your app is listening on port " + PORT);
});

